package program;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConCatTest {

	@Test
	public void ConCatTest() {
class1 junit = new class1();
		
		String result = junit.ConCat("Hello","Kamalpreet");
		assertEquals("HelloKamalpreet",result);
	}

}
