package program;

import static org.junit.Assert.*;

import org.junit.Test;

public class AddTest1 {

	@Test
	public void AddTest1() {
class1 junit = new class1();
		
		int result = junit.add(100,200);
		assertEquals(300,result);
	}

}
